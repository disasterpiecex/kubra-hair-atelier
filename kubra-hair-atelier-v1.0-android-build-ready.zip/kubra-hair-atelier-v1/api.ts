export type HairAnalysis = {
  level: string;
  warmth: string;
  undertone: string;
  conditionNotes: string[];
  confidence: 'low'|'medium'|'high';
  disclaimer?: string;
};

export type PreviewResponse = { previewDataUrl: string; provider: string };

export type HairHistory = {
  chemicalStatus: 'virgin'|'dyed'|'bleached'|'mixed'|'unknown';
  lastProcess: 'under-2-weeks'|'2-6-weeks'|'6-plus-weeks'|'never'|'unknown';
  scalpOrBreakageConcern: boolean;
  permanence: 'temporary'|'semi'|'demi'|'permanent'|'unsure';
};

export type FormulaPlan = {
  readiness: 'ready'|'strand-test-first'|'professional-review';
  summary: string;
  currentCanvas: string;
  requiredCanvas: string;
  route: Array<{title:string;detail:string}>;
  formula: string[];
  maintenance: string[];
  warnings: string[];
};

const API_URL = (process.env.EXPO_PUBLIC_API_URL || '').replace(/\/$/, '');

function photoPart(uri:string): any {
  const ext = (uri.split('.').pop() || 'jpg').split('?')[0].toLowerCase();
  const type = ext === 'png' ? 'image/png' : 'image/jpeg';
  return { uri, name:`hair.${ext === 'png' ? 'png' : 'jpg'}`, type };
}

async function asJson(res:Response){
  const body = await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(body?.detail || body?.message || `Request failed (${res.status})`);
  return body;
}

const localAnalysis:HairAnalysis = {
  level:'8–9', warmth:'mild yellow', undertone:'warm-neutral blonde',
  conditionNotes:['Local demo estimate — connect the AI backend for real photo analysis'],
  confidence:'low',
  disclaimer:'Demo mode does not inspect image pixels. Live photo analysis becomes available when EXPO_PUBLIC_API_URL points to the Kübra Hair Atelier backend.'
};

export async function analyzeHair(photoUri:string):Promise<HairAnalysis>{
  if(!API_URL) return localAnalysis;
  const form = new FormData(); form.append('photo', photoPart(photoUri));
  return asJson(await fetch(`${API_URL}/v1/hair/analyze`, { method:'POST', body:form }));
}

export async function generateHairPreview(photoUri:string, shade:{name:string;hex:string;level:string;tone:string}):Promise<PreviewResponse>{
  if(!API_URL) return {previewDataUrl:photoUri, provider:'mock-local'};
  const form = new FormData();
  form.append('photo', photoPart(photoUri)); form.append('shade_name', shade.name); form.append('shade_hex', shade.hex); form.append('target_level', shade.level); form.append('target_tone', shade.tone);
  return asJson(await fetch(`${API_URL}/v1/hair/preview`, { method:'POST', body:form }));
}

export async function generateComparePreviews(photoUri:string, shades:Array<{id:string;name:string;hex:string;level:string;tone:string}>){
  if(!API_URL) return {previews:Object.fromEntries(shades.map(x=>[x.id,photoUri])),provider:'mock-local'};
  const form = new FormData(); form.append('photo', photoPart(photoUri)); form.append('shades_json', JSON.stringify(shades));
  return asJson(await fetch(`${API_URL}/v1/hair/compare`, { method:'POST', body:form })) as Promise<{previews:Record<string,string>;provider:string}>;
}

function localFormula(analysis:HairAnalysis, shade:{name:string;level:string;tone:string}, history:HairHistory):FormulaPlan{
  const currentNums=(analysis.level.match(/\d+(?:\.\d+)?/g)||[]).map(Number);
  const current=currentNums.length?currentNums.slice(0,2).reduce((a,b)=>a+b,0)/Math.min(currentNums.length,2):undefined;
  const target=Number(shade.level); const needsLift=current!==undefined&&Number.isFinite(target)&&target>current+.75;
  const processed=['dyed','bleached','mixed'].includes(history.chemicalStatus);
  const readiness=history.scalpOrBreakageConcern?'professional-review':(needsLift||processed?'strand-test-first':'ready');
  return {
    readiness,
    summary:`Demo route from estimated level ${analysis.level} toward ${shade.name}. Connect the backend for the full rules engine.`,
    currentCanvas:`Level ${analysis.level} • ${analysis.undertone} • confidence ${analysis.confidence}`,
    requiredCanvas:`Approx. level ${shade.level} • ${shade.tone}`,
    route:[
      {title:'Confirm the canvas',detail:'Check the starting depth and tone in neutral daylight; a photo estimate is not chemical history.'},
      ...(needsLift?[{title:'Create the required canvas',detail:'The target appears lighter than the estimated source. Strand testing is required before deciding on a lifting service.'}]:[{title:'Preserve the current depth',detail:'A deposit-first approach may be possible if the starting canvas is even.'}]),
      {title:'Deposit the target tone',detail:`Use a manufacturer-supported ${shade.name} / ${shade.tone} direction on an even prepared canvas.`}
    ],
    formula:['Brand-specific grams, activator and developer choices are intentionally withheld in local demo mode.'],
    maintenance:['Use color-safe cleansing, cooler water, and a compatible depositing refresh product as needed.'],
    warnings:[...(processed?['Previously processed hair can react unevenly; strand testing is important.']:[]),'Photo analysis cannot determine porosity, elasticity, allergy risk, metallic salts, or exact previous dye chemistry.']
  };
}

export async function generateFormulaPlan(analysis:HairAnalysis, shade:{name:string;hex:string;level:string;tone:string;saturation:string}, history:HairHistory):Promise<FormulaPlan>{
  if(!API_URL) return localFormula(analysis,shade,history);
  return asJson(await fetch(`${API_URL}/v1/hair/formula`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({analysis, shade, history})}));
}

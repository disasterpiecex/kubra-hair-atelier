# Kübra Hair Atelier — v1.0 MVP

A React Native / Expo hair-color exploration app with a FastAPI AI backend.

## What is complete in v1.0

- Premium warm-neutral visual system based on the approved Kübra Hair Atelier direction.
- 11 color families and a broad shade catalog across natural, fashion, grey and pastel colors.
- Persistent multi-step journey: going backward does not erase previous choices.
- Active source photo persists while switching families and shades.
- Favorites, recent shades, compare tray and saved full looks persist between launches.
- Saved looks can include the selected shade, AI preview and generated formulation route.
- 2–4 shade comparison flow using the same source photo.
- Source-hair analysis is cached independently from the target shade.
- Hair-history questionnaire for information a photo cannot safely infer.
- Deterministic rules-first formulation route with safety escalation.
- Local demo fallback: the app stays usable even before a backend is deployed.
- Optional live OpenAI-backed photo analysis and hair recoloring through the server.
- Android APK preview-build configuration and Android App Bundle production configuration.
- iOS bundle configuration retained for a later TestFlight build.

## Important distinction: app vs AI service

The mobile application is buildable without a server. If `EXPO_PUBLIC_API_URL` is not configured, AI screens run in clearly labeled demo mode and never pretend the unchanged photo is a real recolor.

For real AI analysis/recoloring, deploy `backend/` and set `EXPO_PUBLIC_API_URL` to its HTTPS address before building the app. Keep `OPENAI_API_KEY` only on the backend.

## Run locally

```bash
npm install
npx expo start
```

For a real backend on your LAN:

```bash
cd backend
python -m venv .venv
# activate the venv
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

Then start Expo with your computer's reachable address:

```bash
EXPO_PUBLIC_API_URL=http://192.168.1.50:8000 npx expo start
```

## Live AI backend

Create backend environment variables:

```bash
KHA_AI_MODE=openai
OPENAI_API_KEY=your_server_side_key
KHA_VISION_MODEL=gpt-5.6-luna
KHA_IMAGE_MODEL=gpt-image-2
```

Never put the OpenAI API key in `EXPO_PUBLIC_*` variables or in the mobile app.

## Android installable APK

`eas.json` already contains the required preview profile:

```bash
npm install -g eas-cli
eas login
npm install
eas build -p android --profile preview
```

The `preview` profile uses `android.buildType: apk`, producing an APK intended for direct device installation.

For Google Play later:

```bash
eas build -p android --profile production
```

The production profile produces an AAB.

## Backend checks

```bash
cd backend
pytest -q
```

Current included tests verify formulation-route safety behavior for processed hair and reported scalp/breakage concerns.

## Formulation safety boundary

The app estimates visible color properties from photographs, but a photograph cannot reliably determine porosity, elasticity, allergy risk, metallic salts, exact previous dye chemistry or strand strength. The rules engine therefore escalates uncertain/high-risk transformations instead of inventing aggressive chemistry.

Brand-specific gram ratios, developer strengths and exact processing times should only be added from verified manufacturer technical data for the specific product line.

## Remaining deployment work before a real public launch

1. Deploy the backend over HTTPS and configure `EXPO_PUBLIC_API_URL`.
2. Test live AI previews on diverse real photos and refine prompt/quality behavior.
3. Add a verified professional/store product database for exact brand formulas.
4. Run full physical-device QA on Android.
5. Add privacy policy, terms, analytics/crash reporting if desired, and store metadata.
6. Build/sign the production Android AAB; later build iOS through TestFlight/App Store Connect.

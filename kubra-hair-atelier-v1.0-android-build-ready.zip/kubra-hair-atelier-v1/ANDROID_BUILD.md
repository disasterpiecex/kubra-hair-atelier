# Build an installable Android APK

This repository includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`.

## Easiest build path

1. Put this project in a GitHub repository.
2. Open **Actions → Build Android APK → Run workflow**.
3. When the run finishes, open the run and download the artifact named **Kubra-Hair-Atelier-Android-APK**.
4. Extract the artifact ZIP and install `Kubra-Hair-Atelier-v1.0-debug.apk` on Android.

This is a debug-signed APK intended for direct device testing. It does not require an Expo account or Android signing key.

## Local build path

On a machine with Node.js, Java 17, Android SDK and internet access:

```bash
npm install
npm run android:debug-apk
```

The APK will be at:

`android/app/build/outputs/apk/debug/app-debug.apk`

## Live AI

The Android app can be navigated in demo mode without a deployed backend. Live hair analysis/recoloring requires the backend URL and API provider configuration described in the main README.

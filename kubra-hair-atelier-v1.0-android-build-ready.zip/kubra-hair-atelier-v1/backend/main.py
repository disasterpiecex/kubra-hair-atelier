import base64
import json
import os
from typing import Literal

import httpx
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Kübra Hair Atelier AI API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
AI_MODE = os.getenv("KHA_AI_MODE", "mock").lower()  # mock | openai
VISION_MODEL = os.getenv("KHA_VISION_MODEL", "gpt-5.6-luna")
IMAGE_MODEL = os.getenv("KHA_IMAGE_MODEL", "gpt-image-2")

MAX_IMAGE_BYTES = 15 * 1024 * 1024

async def read_photo(photo: UploadFile) -> bytes:
    if photo.content_type not in {"image/jpeg", "image/png", "image/webp", None}:
        raise HTTPException(415, "Please upload a JPEG, PNG, or WebP image.")
    data = await photo.read(MAX_IMAGE_BYTES + 1)
    if not data:
        raise HTTPException(400, "The uploaded photo is empty.")
    if len(data) > MAX_IMAGE_BYTES:
        raise HTTPException(413, "Photo is too large. Maximum size is 15 MB.")
    return data

class HairAnalysis(BaseModel):
    level: str
    warmth: str
    undertone: str
    conditionNotes: list[str]
    confidence: Literal["low", "medium", "high"]
    disclaimer: str


def require_live_key():
    if not OPENAI_API_KEY:
        raise HTTPException(503, "Live AI mode requires OPENAI_API_KEY on the backend server.")


def mime_for(filename: str | None, content_type: str | None) -> str:
    if content_type in {"image/jpeg", "image/png", "image/webp"}:
        return content_type
    name = (filename or "").lower()
    return "image/png" if name.endswith(".png") else "image/jpeg"


@app.get("/health")
def health():
    return {"ok": True, "mode": AI_MODE, "visionModel": VISION_MODEL, "imageModel": IMAGE_MODEL}


@app.post("/v1/hair/analyze", response_model=HairAnalysis)
async def analyze(photo: UploadFile = File(...)):
    data = await read_photo(photo)
    if AI_MODE != "openai":
        return HairAnalysis(
            level="8–9",
            warmth="mild yellow",
            undertone="warm-neutral blonde",
            conditionNotes=["Demo analysis only", "Confirm processing history before formulation"],
            confidence="low",
            disclaimer="Photo-based hair analysis is an estimate; lighting, white balance and previous chemical processing can change the result.",
        )

    require_live_key()
    mime = mime_for(photo.filename, photo.content_type)
    data_url = f"data:{mime};base64,{base64.b64encode(data).decode()}"
    schema = {
        "type": "object",
        "properties": {
            "level": {"type": "string"},
            "warmth": {"type": "string"},
            "undertone": {"type": "string"},
            "conditionNotes": {"type": "array", "items": {"type": "string"}},
            "confidence": {"type": "string", "enum": ["low", "medium", "high"]},
            "disclaimer": {"type": "string"},
        },
        "required": ["level", "warmth", "undertone", "conditionNotes", "confidence", "disclaimer"],
        "additionalProperties": False,
    }
    payload = {
        "model": VISION_MODEL,
        "input": [{
            "role": "user",
            "content": [
                {"type": "input_text", "text": "Estimate only visible hair-color properties from this photo. Do not infer ethnicity, identity, age, health diagnoses, or hidden chemical history. Return JSON matching the schema. Hair level should use the salon 1-10 depth scale where possible. Note lighting uncertainty."},
                {"type": "input_image", "image_url": data_url, "detail": "high"},
            ],
        }],
        "text": {"format": {"type": "json_schema", "name": "hair_analysis", "schema": schema, "strict": True}},
    }
    async with httpx.AsyncClient(timeout=90) as client:
        r = await client.post("https://api.openai.com/v1/responses", headers={"Authorization": f"Bearer {OPENAI_API_KEY}"}, json=payload)
    if r.status_code >= 400:
        raise HTTPException(502, f"Vision provider error: {r.text[:400]}")
    body = r.json()
    text = body.get("output_text")
    if not text:
        # Responses REST may expose text only in nested output depending on SDK/API version.
        for item in body.get("output", []):
            for c in item.get("content", []):
                if c.get("type") == "output_text":
                    text = c.get("text")
                    break
    if not text:
        raise HTTPException(502, "Vision provider returned no structured analysis.")
    return HairAnalysis.model_validate(json.loads(text))


def preview_prompt(shade_name: str, shade_hex: str, target_level: str, target_tone: str) -> str:
    return f"""Edit this exact photograph as a realistic hair-color try-on. Change ONLY the visible hair color to {shade_name} ({shade_hex}), target visual depth approximately level {target_level}, tone {target_tone}. Preserve the person's identity, face, skin, makeup, eyes, eyebrows, clothing, background, hairstyle, strand geometry, texture, highlights, shadows, flyaways, and lighting. Do not change haircut, hair length, curl pattern, volume, facial features, body shape, or camera framing. Make the new color interact naturally with the original illumination and preserve realistic dimensional variation instead of a flat color overlay. This is a visual preview, not a promise of chemically achievable results."""


async def live_edit(data: bytes, filename: str, mime: str, prompt: str) -> str:
    require_live_key()
    files = {"image": (filename or "hair.jpg", data, mime)}
    form = {
        "model": IMAGE_MODEL,
        "prompt": prompt,
        "size": "1024x1024",
        "quality": "high",
        "output_format": "jpeg",
    }
    async with httpx.AsyncClient(timeout=180) as client:
        r = await client.post("https://api.openai.com/v1/images/edits", headers={"Authorization": f"Bearer {OPENAI_API_KEY}"}, data=form, files=files)
    if r.status_code >= 400:
        raise HTTPException(502, f"Image provider error: {r.text[:500]}")
    body = r.json()
    item = (body.get("data") or [{}])[0]
    b64 = item.get("b64_json")
    if b64:
        return f"data:image/jpeg;base64,{b64}"
    url = item.get("url")
    if url:
        async with httpx.AsyncClient(timeout=90) as client:
            image = await client.get(url)
        image.raise_for_status()
        return f"data:image/jpeg;base64,{base64.b64encode(image.content).decode()}"
    raise HTTPException(502, "Image provider returned no image.")


@app.post("/v1/hair/preview")
async def preview(
    photo: UploadFile = File(...),
    shade_name: str = Form(...),
    shade_hex: str = Form(...),
    target_level: str = Form(...),
    target_tone: str = Form(...),
):
    data = await read_photo(photo)
    mime = mime_for(photo.filename, photo.content_type)
    if AI_MODE != "openai":
        # Intentional UX fallback: in mock mode we return the source photo unchanged,
        # clearly labeled as mock in the client instead of pretending a filter is AI.
        return {"previewDataUrl": f"data:{mime};base64,{base64.b64encode(data).decode()}", "provider": "mock-source-image"}
    out = await live_edit(data, photo.filename or "hair.jpg", mime, preview_prompt(shade_name, shade_hex, target_level, target_tone))
    return {"previewDataUrl": out, "provider": IMAGE_MODEL}


@app.post("/v1/hair/compare")
async def compare(photo: UploadFile = File(...), shades_json: str = Form(...)):
    try:
        shades = json.loads(shades_json)
    except json.JSONDecodeError:
        raise HTTPException(400, "Invalid shades_json")
    if not isinstance(shades, list) or not 2 <= len(shades) <= 4:
        raise HTTPException(400, "Compare requires 2–4 shades")
    data = await read_photo(photo)
    mime = mime_for(photo.filename, photo.content_type)
    if AI_MODE != "openai":
        source = f"data:{mime};base64,{base64.b64encode(data).decode()}"
        return {"previews": {str(x["id"]): source for x in shades}, "provider": "mock-source-image"}
    previews = {}
    for shade in shades:
        previews[str(shade["id"])] = await live_edit(
            data,
            photo.filename or "hair.jpg",
            mime,
            preview_prompt(str(shade["name"]), str(shade["hex"]), str(shade["level"]), str(shade["tone"])),
        )
    return {"previews": previews, "provider": IMAGE_MODEL}

class FormulaRequest(BaseModel):
    analysis: HairAnalysis
    shade: dict
    history: dict

class RouteStep(BaseModel):
    title: str
    detail: str

class FormulaPlan(BaseModel):
    readiness: Literal["ready", "strand-test-first", "professional-review"]
    summary: str
    currentCanvas: str
    requiredCanvas: str
    route: list[RouteStep]
    formula: list[str]
    maintenance: list[str]
    warnings: list[str]


def numeric_level(value: str) -> float | None:
    import re
    nums = [float(x) for x in re.findall(r"\d+(?:\.\d+)?", value or "")]
    if not nums:
        return None
    return sum(nums[:2]) / min(2, len(nums))

@app.post("/v1/hair/formula", response_model=FormulaPlan)
def formula(req: FormulaRequest):
    current = numeric_level(req.analysis.level)
    try:
        target = float(req.shade.get("level", ""))
    except Exception:
        target = None
    status = req.history.get("chemicalStatus", "unknown")
    concern = bool(req.history.get("scalpOrBreakageConcern", False))
    last = req.history.get("lastProcess", "unknown")
    permanence = req.history.get("permanence", "unsure")
    target_name = str(req.shade.get("name", "target shade"))
    tone = str(req.shade.get("tone", "target tone"))

    needs_lift = bool(current is not None and target is not None and target > current + 0.75)
    large_lift = bool(current is not None and target is not None and target >= current + 3)
    processed = status in {"dyed", "bleached", "mixed", "unknown"}

    if concern or (large_lift and processed) or (last == "under-2-weeks" and needs_lift):
        readiness = "professional-review"
    elif needs_lift or processed:
        readiness = "strand-test-first"
    else:
        readiness = "ready"

    route: list[RouteStep] = []
    warnings: list[str] = []
    formula_lines: list[str] = []

    route.append(RouteStep(title="Confirm the canvas", detail=f"Photo estimate: level {req.analysis.level}, {req.analysis.undertone}. Verify this in neutral daylight before mixing color."))

    if needs_lift:
        route.append(RouteStep(title="Create a lighter canvas", detail=f"{target_name} reads best around level {req.shade.get('level')}. Because the estimated starting depth is darker, lifting may be required before depositing the target tone."))
        formula_lines.append("Do not choose developer strength from the photo alone. Use the lightener manufacturer's on-scalp/off-scalp directions and a strand test; professional review is recommended for previously colored hair.")
    else:
        route.append(RouteStep(title="Preserve the current depth", detail="The estimated starting depth is already close enough to the target depth that a deposit-first approach may be possible."))

    warm = (req.analysis.warmth or "").lower() + " " + (req.analysis.undertone or "").lower()
    if any(x in warm for x in ["yellow", "gold", "orange", "warm", "copper"]):
        route.append(RouteStep(title="Control residual warmth", detail=f"The source appears warm. For a {tone} result, neutralize only the warmth that remains after any lifting; over-neutralizing can muddy fashion shades."))

    route.append(RouteStep(title="Deposit the target", detail=f"Apply a formulation from the {target_name} / {tone} family once the canvas is even. Saturation and processing time should follow the chosen color line, not a universal timer."))
    route.append(RouteStep(title="Evaluate before repeating", detail="Rinse, dry, and evaluate the result in neutral light before adding another oxidative step."))

    if permanence in {"temporary", "semi"}:
        formula_lines.append(f"Preferred route: a direct/semi-permanent {target_name} shade on the prepared canvas; no developer unless the manufacturer specifically requires one.")
    elif permanence == "demi":
        formula_lines.append(f"Preferred route: a demi-permanent {target_name}/{tone} formula with the dedicated low-strength activator specified by that color line.")
    elif permanence == "permanent":
        formula_lines.append(f"Permanent color can be considered only if the chosen brand has an appropriate {target_name}/{tone} shade and the required canvas is compatible; follow that line's exact mixing ratio and developer pairing.")
    else:
        formula_lines.append(f"Choose a color line first; the app should then convert {target_name} into brand-specific grams and activator ratios from that manufacturer's technical chart.")

    if status in {"dyed", "mixed"} and needs_lift:
        warnings.append("Artificial pigment does not reliably lift with ordinary permanent color. Previously dyed lengths may require professional color removal/lightening strategy.")
    if status == "bleached":
        warnings.append("Previously bleached hair can process unevenly and may be more fragile; strand testing is especially important.")
    if last == "under-2-weeks":
        warnings.append("The hair was processed recently. Avoid stacking another aggressive chemical service without assessing scalp comfort and strand integrity.")
    if concern:
        warnings.append("Scalp irritation or visible breakage was reported. The app should not recommend an at-home lightening step until this is professionally assessed.")
    warnings.append("Photo analysis cannot determine porosity, elasticity, metallic salts, allergy risk, or exact previous dye chemistry.")
    warnings.append("Patch/allergy testing and strand testing should follow the selected product manufacturer's instructions.")

    maint = [
        "Use color-safe cleansing and cooler water to slow fading.",
        "Refresh fashion tones with a compatible depositing mask/direct dye rather than repeated lifting.",
        "Reassess the starting canvas before every future formula because the hair changes after each service.",
    ]

    return FormulaPlan(
        readiness=readiness,
        summary=f"Route from estimated level {req.analysis.level} to {target_name}.",
        currentCanvas=f"Level {req.analysis.level} • {req.analysis.undertone} • confidence {req.analysis.confidence}",
        requiredCanvas=f"Approx. level {req.shade.get('level')} • {tone}",
        route=route,
        formula=formula_lines,
        maintenance=maint,
        warnings=warnings,
    )

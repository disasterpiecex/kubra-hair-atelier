from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def payload(level="8–9", target="10", status="bleached", concern=False):
    return {
        "analysis": {
            "level": level,
            "warmth": "mild yellow",
            "undertone": "warm-neutral blonde",
            "conditionNotes": [],
            "confidence": "medium",
            "disclaimer": "estimate"
        },
        "shade": {"name":"Pastel Blue","hex":"#BDD2F0","level":target,"tone":"Soft cool","saturation":"Pastel"},
        "history": {"chemicalStatus":status,"lastProcess":"6-plus-weeks","scalpOrBreakageConcern":concern,"permanence":"semi"}
    }

def test_formula_flags_bleached_lift():
    r=client.post('/v1/hair/formula', json=payload())
    assert r.status_code == 200
    body=r.json()
    assert body['readiness'] in {'strand-test-first','professional-review'}
    assert body['route']
    assert body['warnings']

def test_formula_escalates_breakage_concern():
    r=client.post('/v1/hair/formula', json=payload(concern=True))
    assert r.status_code == 200
    assert r.json()['readiness'] == 'professional-review'
